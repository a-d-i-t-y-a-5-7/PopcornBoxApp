export interface IFavouriteMedia{
    UserId : number;
    MediaId : number;
}