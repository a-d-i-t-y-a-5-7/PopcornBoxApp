export interface IFavouriteSong{
    UserId : number;
    SongId : number;
}