export interface Song {
    songsId?:number,
    name?:string,
    singers?:string,
    composer?:string,
    lyrics?:string,
    year?:number,
    genreId?:number,
    clientId?:number,
    thumbnail?:string,
    songUrl?:string,
}