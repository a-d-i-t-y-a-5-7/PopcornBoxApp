export class ClientSong {
    name="";
    singers="";
    composer="";
    lyrics="";
    year:any;
    genreId=0;
    clientId=0;
    thumbnail="";
    songUrl="";
}