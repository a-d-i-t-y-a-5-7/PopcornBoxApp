export class ClientMedia {
    name="";
    actors="";
    directors="";
    genreId=0;
    year:any;
    mediaId=0;
    clientId=0;
    thumbnail="";
    trailer="";
    fullLength="";
}