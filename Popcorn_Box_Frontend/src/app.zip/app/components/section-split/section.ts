import { Media } from "src/app/models/media";

export class Section {
    public sectionHeader = 'Home';

    public sectionItems: Media[] = [];
}